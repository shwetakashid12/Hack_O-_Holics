package com.example.hackthon_covid;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class HelpLine_No extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help_line__no);
    }
}
